import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class VentanaUsuarios extends JFrame {

	public VentanaUsuarios (){
		
		init();
	}

	private void init() {
		
			setTitle ("Elige tu Guardi�n");
			setSize (1280, 760);
			setVisible (true);
			
			JPanel parteIzquierdaUsu= new JPanel();
			
			JButton usuario= new JButton ("Usuario1");
			JButton usuario1= new JButton ("Un Usuario por cada tupla");
			
			parteIzquierdaUsu.setLayout (new GridLayout (2,1));
			
			parteIzquierdaUsu.add(usuario);
			parteIzquierdaUsu.add(usuario1);			
			
			
			
			setLayout (new BorderLayout());
			
//			add (parteDeArriba, BorderLayout.NORTH);
//			add (parteCentral, BorderLayout.CENTER);
			add (parteIzquierdaUsu, BorderLayout.WEST);
//			add (parteInferior, BorderLayout.SOUTH);
//			add (parteDerecha, BorderLayout.EAST);

		}
		
	}
		
	