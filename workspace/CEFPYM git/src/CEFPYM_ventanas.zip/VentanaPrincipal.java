import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VentanaPrincipal extends JFrame {

	private int contador;
	private String usuario;
	
	//Habr� que sacar el usuario de la base de datos.
	public VentanaPrincipal(){
		init();
		contador=0;
		usuario="";
	}

	private void init() {
		setTitle ("Como Espada Forjada Por Yunque y Martillo");
		setSize (1280, 760);
		setVisible (true);
		
		JPanel parteDeArriba= new JPanel();
		
		JLabel etiquetaContador= new JLabel("P�gina "+ getContador());
		JLabel logo = new JLabel ("Aqu� ir�a el logo");
		JLabel etiquetaUsuario= new JLabel ("El guerrero "+ getUsuario()+ " est� sumido en Tinieblas");
		
		parteDeArriba.setLayout(new GridLayout (1, 3));
		
		parteDeArriba.add (etiquetaContador);
		parteDeArriba.add (logo);
		parteDeArriba.add (etiquetaUsuario);
		
		JPanel parteCentral = new JPanel();
		
		JLabel textoLectura= new JLabel ("Aqu� ir�a el texto");
		
		parteCentral.add(textoLectura);
		
		JPanel parteDerecha= new JPanel();
		
		JButton opcion1= new JButton ("Aqu� a la p�gina X");
		JButton opcion2= new JButton ("Aqu� a la p�gina Y");
		JButton opcion3= new JButton ("Aqu� alguna acci�n extra");		
		
		parteDerecha.setLayout(new GridLayout (3,1));		
		
		parteDerecha.add(opcion1);
		parteDerecha.add(opcion2);
		parteDerecha.add(opcion3);
		
		JPanel parteInferior= new JPanel();
		
		JButton opcionNuevaPartida= new JButton ("Nueva Partida");
		JButton opcionSalvarPartida= new JButton ("Guardar Progreso");
		JButton opcionCargarPartida= new JButton ("Cargar Partida");
		JButton opcionSalir= new JButton ("Salir");
		
		parteInferior.setLayout(new GridLayout (4,1));		
		
		parteInferior.add(opcionNuevaPartida);
		parteInferior.add(opcionSalvarPartida);
		parteInferior.add(opcionCargarPartida);
		parteInferior.add(opcionSalir);
		
		JPanel parteIzquierda=new JPanel();
		
		JLabel imagen= new JLabel ("Aqu� ir�a la imagen");
		parteIzquierda.add(imagen);
		
		setLayout (new BorderLayout());
		
		add (parteDeArriba, BorderLayout.NORTH);
		add (parteCentral, BorderLayout.CENTER);
		add (parteIzquierda, BorderLayout.WEST);
		add (parteInferior, BorderLayout.SOUTH);
		add (parteDerecha, BorderLayout.EAST);
		
	}
	
	public int getContador (){
		
		return contador;
	}
	
	public String getUsuario(){
		
		return usuario;
	}
	
	public static void main(String[] args) {
		
		new VentanaUsuarios();
		
		new VentanaPrincipal();		
		
		
	}
}